select *from customers
select *from drugs
select *from sales

SELECT SUM(s.Quantity * d.UnitPrice) AS TotalRevenue 
FROM Sales s 
JOIN Drugs d ON s.DrugID = d.DrugID;
SELECT d.DrugName, SUM(s.Quantity) AS TotalDemand 
FROM Sales s 
JOIN Drugs d ON s.DrugID = d.DrugID 
GROUP BY d.DrugName 
ORDER BY TotalDemand DESC;

SELECT DATE_FORMAT(STR_TO_DATE(s.SaleDate,'%c/%e/%Y'),'%Y-%m') AS Month, 
       SUM(s.Quantity * d.UnitPrice) AS Revenue 
FROM Sales s 
JOIN Drugs d ON s.DrugID = d.DrugID 
where STR_TO_DATE(s.SaleDate,'%c/%e/%Y') is not null
GROUP BY Month
ORDER BY Month; 

SELECT DrugName, ShelfLifeMonths 
FROM Drugs 
WHERE ShelfLifeMonths < 12;

High-Order Hos/Pharma

SELECT
    c.CustomerName,
    c.CustomerType,
    SUM(s.Quantity) AS Total_Orders
FROM Sales s
JOIN Customers c
    ON s.CustomerID = c.CustomerID
WHERE LOWER(c.CustomerType)
    IN ('hospital', 'pharmacy')
GROUP BY
    c.CustomerID,
    c.CustomerName,
    c.CustomerType
ORDER BY Total_Orders DESC
LIMIT 10;

Customer Purchase Behaviour-

SELECT
    c.CustomerName,
    c.CustomerType,
    d.DrugName,
    d.Category,
    s.Quantity,
    s.SaleDate
FROM Customers c
JOIN Sales s
    ON c.CustomerID = s.CustomerID
JOIN Drugs d
    ON s.DrugID = d.DrugID
ORDER BY c.CustomerName;

